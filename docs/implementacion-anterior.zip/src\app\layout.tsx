import type { Metadata } from "next";
import localFont from "next/font/local";
import Analytics from "@/components/Analytics";
import Header from "@/components/Header";
import { Footer } from "@/components/Editorial";
import { site } from "@/config/site";
import "./globals.css";
const monument = localFont({
  src: "../../font/monumentextended-ultrabold.woff2",
  weight: "900",
  display: "swap",
  variable: "--font-monument",
});
const satoshi = localFont({
  src: "../../font/Satoshi-Variable.woff2",
  preload: false,
  weight: "300 900",
  display: "swap",
  variable: "--font-satoshi",
});
export const metadata: Metadata = {
  metadataBase: site.origin ? new URL(site.origin) : undefined,
  title: { default: "Nord Studios", template: "%s | Nord Studios" },
  icons: { icon: "/brand/icon.png" },
  verification: { google: process.env.GOOGLE_SITE_VERIFICATION },
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es-PE" className={monument.variable + " " + satoshi.variable}>
      <body>
        <a className="skip" href="#contenido">
          Saltar al contenido
        </a>
        <Header />
        <main id="contenido" tabIndex={-1}>
          {children}
        </main>
        <Footer />
        {process.env.GA4_ID?.match(/^G-[A-Z0-9]+$/) && (
          <Analytics id={process.env.GA4_ID} />
        )}
      </body>
    </html>
  );
}
