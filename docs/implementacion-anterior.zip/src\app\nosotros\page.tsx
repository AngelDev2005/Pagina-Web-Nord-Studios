import Image from "next/image";
import {
  Crumbs,
  HeroTitle,
  Label,
  Process,
  Close,
} from "@/components/Editorial";
import { meta } from "@/lib/seo";
export const metadata = meta(
  "Estudio de diseño independiente en Trujillo",
  "Conoce la filosofía de Nord Studios y nuestro proceso de dirección creativa, identidad y comunicación visual.",
  "/nosotros",
);
export default function Page() {
  return (
    <>
      <Crumbs items={[["/nosotros", "Nosotros"]]} />
      <HeroTitle
        label="Nosotros / Trujillo, Perú"
        title="Un estudio independiente."
        intro="Más de tres años de experiencia en diseño gráfico independiente dieron forma a Nord Studios. Trabajamos con negocios que quieren expresar mejor quiénes son."
      />
      <div className="paper">
        <section className="wrap section studio">
          <div className="studio-photo">
            <Image
              src="/brand/pliegue-detalle.webp"
              width={960}
              height={720}
              sizes="(max-width:740px) 90vw, 43vw"
              alt="Encuentro entre metal cepillado y esmalte naranja en la pieza del estudio"
            />
          </div>
          <div className="reading">
            <Label>Nuestra filosofía</Label>
            <h2>Cada decisión tiene un porqué.</h2>
            <p>
              Una marca se encuentra en muchos lugares. Nos interesa que
              conserve su carácter en una etiqueta, una pantalla o una
              presentación comercial.
            </p>
            <p>
              Por eso empezamos por escuchar. Definimos contigo el problema de
              comunicación, elegimos una dirección y la llevamos a piezas que tu
              equipo pueda usar.
            </p>
          </div>
        </section>
      </div>
      <Process />
      <Close />
    </>
  );
}
