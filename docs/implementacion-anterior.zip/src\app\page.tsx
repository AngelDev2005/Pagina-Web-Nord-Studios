import Image from "next/image";
import { ArrowDown } from "lucide-react";
import {
  Button,
  Label,
  ServiceRows,
  Process,
  FAQ,
  Close,
  ProjectCards,
} from "@/components/Editorial";
import { projects } from "@/lib/content";
import { meta, Structured } from "@/lib/seo";
import { site } from "@/config/site";
import { testimonials } from "@/config/es";
export const metadata = meta(
  "Estudio creativo y branding en Trujillo, Perú",
  "Dirección creativa, identidad visual y diseño estratégico para marcas. Descubre el trabajo de Nord Studios en Trujillo, Perú.",
  "/",
);
export default function Home() {
  const published = projects();
  const featured = published.filter((p) => p.featured);
  return (
    <>
      <Structured
        data={{
          "@type": "Organization",
          name: site.name,
          url: site.origin,
          areaServed: "Perú",
          sameAs: site.socials.map(([, url]) => url),
        }}
      />
      <Structured
        data={{
          "@type": "WebSite",
          name: site.name,
          url: site.origin,
          inLanguage: "es-PE",
        }}
      />
      <section className="hero">
        <div className="wrap hero-grid">
          <div className="hero-copy">
            <Label>Estudio creativo independiente</Label>
            <h1>
              Diseñamos
              <br />
              marcas con
              <br />
              <em>carácter.</em>
            </h1>
            <p>
              Dirección creativa, identidad visual y diseño estratégico para
              marcas que buscan diferenciarse.
            </p>
            <div className="actions">
              <Button href="/contacto">Inicia tu proyecto</Button>
              <Button
                href={published.length ? "/proyectos" : "/servicios"}
                secondary
              >
                {published.length ? "Ver proyectos" : "Explorar servicios"}
              </Button>
            </div>
          </div>
          <div className="sculpture">
            <Image
              src="/brand/pliegue.webp"
              width={1200}
              height={1200}
              sizes="(max-width:740px) clamp(184px, calc(58vw - 16px), 334px), 52vw"
              preload
              fetchPriority="high"
              alt="Cinta escultórica de titanio oscuro con un pliegue naranja y bordes iluminados"
            />
          </div>
        </div>
        <div className="wrap hero-base">
          <span>TRUJILLO, PERÚ</span>
          <span>
            BRANDING <i>/</i> DESIGN <i>/</i> STRATEGY
          </span>
          <a href="#disciplinas" aria-label="Descubrir servicios">
            <ArrowDown size={17} />
          </a>
        </div>
      </section>
      {featured.length > 0 && (
        <section className="wrap section">
          <Label>Portafolio</Label>
          <h2>Proyectos seleccionados.</h2>
          <ProjectCards items={featured} />
          <Button secondary href="/proyectos">
            Todos los proyectos
          </Button>
        </section>
      )}
      <section className="paper" id="disciplinas">
        <div className="wrap section">
          <div className="section-head">
            <div>
              <Label>Servicios del estudio</Label>
              <h2>Nuestras disciplinas.</h2>
            </div>
            <Button secondary href="/servicios">
              Ver servicios
            </Button>
          </div>
          <ServiceRows />
        </div>
      </section>
      <section id="estudio" className="wrap section studio">
        <div className="studio-photo">
          <Image
            src="/brand/pliegue-detalle.webp"
            width={960}
            height={720}
            sizes="(max-width:740px) 90vw, 43vw"
            alt="Detalle de las superficies y la luz en la escultura de Nord Studios"
          />
        </div>
        <div>
          <Label>Nord Studios / El estudio</Label>
          <h2>
            Diseño con
            <br />
            dirección.
          </h2>
          <p className="lead">
            Somos un estudio creativo independiente de Trujillo. Llevamos más de
            tres años dando forma a identidades y piezas gráficas.
          </p>
          <p>
            Trabajas directamente con quien diseña tu marca. Desde la primera
            conversación hasta los archivos finales, cada decisión parte de lo
            que tu negocio necesita comunicar.
          </p>
          <Button secondary href="/nosotros">
            Conoce el estudio
          </Button>
        </div>
      </section>
      <div className="paper">
        <Process />
      </div>
      {testimonials.length > 0 && (
        <section className="wrap section">
          <h2>En palabras de nuestros clientes.</h2>
          {testimonials.map((t) => (
            <blockquote key={t.author}>
              {t.quote}
              <cite>{t.author}</cite>
            </blockquote>
          ))}
        </section>
      )}
      <FAQ />
      <Close />
    </>
  );
}
