import Image from "next/image";
import {
  Crumbs,
  HeroTitle,
  ProjectCards,
  Close,
  Button,
} from "@/components/Editorial";
import { projects } from "@/lib/content";
import { services } from "@/config/es";
import { meta } from "@/lib/seo";
import { notFound } from "next/navigation";
type Props = { params: Promise<{ slug: string }> };
export const generateStaticParams = () =>
  projects().map(({ slug }) => ({ slug }));
async function get(p: Props) {
  const { slug } = await p.params;
  return projects().find((i) => i.slug === slug) ?? notFound();
}
export async function generateMetadata(props: Props) {
  const p = await get(props);
  return meta(
    p.seoTitle || p.title,
    p.seoDescription || p.description,
    "/proyectos/" + p.slug,
    true,
    p.ogImage || p.cover.src,
  );
}
export default async function Page(props: Props) {
  const p = await get(props),
    all = projects(),
    next =
      all.length > 1
        ? all[(all.findIndex((item) => item.slug === p.slug) + 1) % all.length]
        : undefined,
    related = all.filter((i) => i.slug !== p.slug && i.category === p.category);
  return (
    <>
      <Crumbs
        items={[
          ["/proyectos", "Proyectos"],
          ["/proyectos/" + p.slug, p.title],
        ]}
      />
      <HeroTitle
        label={[
          services.find((s) => s.slug === p.category)?.short,
          p.client,
          p.year,
        ]
          .filter(Boolean)
          .join(" / ")}
        title={p.title}
        intro={p.description}
      />
      <Image
        className="widepic"
        {...p.cover}
        alt={p.cover.alt}
        sizes="100vw"
        priority
      />
      <div className="paper">
        <div className="wrap reading section">
          {[
            ["Contexto", p.context],
            ["Desafío", p.challenge],
            ["Concepto", p.concept],
            ["Solución", p.solution],
          ].map(([t, b]) => (
            <section key={t}>
              <h2>{t}</h2>
              <p>{b}</p>
            </section>
          ))}
          {[
            ["Entregables", p.deliverables],
            ["Resultados", p.results],
          ].map(
            ([t, values]) =>
              Array.isArray(values) &&
              values.length > 0 && (
                <section key={String(t)}>
                  <h2>{t}</h2>
                  <ul>
                    {values.map((i) => (
                      <li key={i}>{i}</li>
                    ))}
                  </ul>
                </section>
              ),
          )}
        </div>
      </div>
      <div className="wrap gallery">
        {p.gallery.map((i) => (
          <Image key={i.src} {...i} sizes="90vw" alt={i.alt} />
        ))}
        {p.videos.map((v) => (
          <video
            key={v.src}
            controls
            preload="none"
            poster={v.poster}
            aria-label={v.title}
            src={v.src}
          >
            {v.captions && (
              <track kind="captions" srcLang="es" src={v.captions} default />
            )}
          </video>
        ))}
      </div>
      {related.length > 0 && (
        <section className="wrap section">
          <h2>Casos relacionados.</h2>
          <ProjectCards items={related} />
        </section>
      )}
      <div className="wrap section actions">
        <Button href={"/servicios/" + p.category}>Explorar el servicio</Button>
        {next && (
          <Button secondary href={"/proyectos/" + next.slug}>
            Siguiente proyecto · {next.title}
          </Button>
        )}
      </div>
      <Close />
    </>
  );
}
