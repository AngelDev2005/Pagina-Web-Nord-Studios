import Link from "next/link";
import {
  Crumbs,
  HeroTitle,
  ProjectCards,
  Button,
  Close,
} from "@/components/Editorial";
import { projects } from "@/lib/content";
import { services } from "@/config/es";
import { meta } from "@/lib/seo";
export function generateMetadata() {
  return meta(
    "Portafolio de diseño y branding",
    "Casos de identidad visual, diseño y comunicación de Nord Studios.",
    "/proyectos",
    projects().length > 0,
  );
}
export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ categoria?: string }>;
}) {
  const all = projects(),
    { categoria } = await searchParams;
  const cats = services.filter((s) => all.some((p) => p.category === s.slug));
  const selected = cats.some((c) => c.slug === categoria)
    ? categoria
    : undefined;
  return (
    <>
      <Crumbs items={[["/proyectos", "Proyectos"]]} />
      <HeroTitle
        label="Portafolio"
        title="Proyectos seleccionados."
        intro="Una mirada a la idea, las decisiones de diseño y las aplicaciones detrás de cada identidad."
      />
      <div className="paper">
        <div className="wrap section">
          {all.length ? (
            <>
              <nav className="filters" aria-label="Filtrar por disciplina">
                {[{ slug: "", short: "Todos" }, ...cats].map((c) => (
                  <Link
                    key={c.slug}
                    aria-current={
                      (selected || "") === c.slug ? "true" : undefined
                    }
                    href={
                      c.slug ? "/proyectos?categoria=" + c.slug : "/proyectos"
                    }
                  >
                    {c.short}
                  </Link>
                ))}
              </nav>
              <ProjectCards
                items={
                  selected ? all.filter((p) => p.category === selected) : all
                }
              />
            </>
          ) : (
            <div className="empty-panel">
              <h2>Estamos preparando los casos.</h2>
              <p>
                Mientras seleccionamos los proyectos del portafolio, puedes
                conocer cómo trabajamos cada disciplina.
              </p>
              <Button secondary href="/servicios">
                Explorar servicios
              </Button>
            </div>
          )}
        </div>
      </div>
      <Close />
    </>
  );
}
