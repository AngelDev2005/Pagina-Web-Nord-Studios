import { services, faqs } from "@/config/es";
import { site, whatsapp } from "@/config/site";
import {
  Crumbs,
  HeroTitle,
  Button,
  Label,
  Process,
  FAQ,
  ProjectCards,
} from "@/components/Editorial";
import { meta, Structured } from "@/lib/seo";
import { projects } from "@/lib/content";
import { notFound } from "next/navigation";
type Props = { params: Promise<{ slug: string }> };
export const generateStaticParams = () =>
  services.map(({ slug }) => ({ slug }));
async function get(p: Props) {
  const { slug } = await p.params;
  return services.find((s) => s.slug === slug) ?? notFound();
}
export async function generateMetadata(p: Props) {
  const s = await get(p);
  return meta(s.name + " en Perú", s.intro, "/servicios/" + s.slug);
}
export default async function Page(p: Props) {
  const s = await get(p),
    related = projects().filter((item) => item.category === s.slug);
  return (
    <>
      <Crumbs
        items={[
          ["/servicios", "Servicios"],
          ["/servicios/" + s.slug, s.short],
        ]}
      />
      <Structured
        data={{
          "@type": "Service",
          name: s.name,
          description: s.body,
          provider: { "@type": "Organization", name: site.name },
          areaServed: "Perú",
        }}
      />
      <HeroTitle
        label={"Disciplina / 0" + (services.indexOf(s) + 1)}
        title={s.name}
        intro={s.intro}
      />
      <section className="paper">
        <div className="wrap section split">
          <div>
            <Label>El alcance</Label>
            <h2>Qué incluye.</h2>
          </div>
          <div className="reading">
            <p className="lead">{s.body}</p>
            <h3>Posibles entregables</h3>
            <ul>
              {s.items.map((i) => (
                <li key={i}>{i}</li>
              ))}
            </ul>
            <Button href={"/contacto?servicio=" + s.slug}>
              Cotizar {s.short.toLowerCase()}
            </Button>
            {whatsapp(s.name) && (
              <Button secondary href={whatsapp(s.name)}>
                WhatsApp
              </Button>
            )}
          </div>
        </div>
      </section>
      <Process />
      {related.length > 0 && (
        <section className="wrap section">
          <h2>Proyectos relacionados.</h2>
          <ProjectCards items={related} />
        </section>
      )}
      <FAQ items={[[s.question, s.answer], faqs[2], faqs[5]]} />
    </>
  );
}
