import { Crumbs, HeroTitle } from "@/components/Editorial";
import { meta } from "@/lib/seo";
export const metadata = meta(
  "Términos y condiciones",
  "Alcance del sitio y condiciones para solicitar una propuesta de diseño.",
  "/terminos",
  false,
);
export default function Page() {
  return (
    <>
      <Crumbs items={[["/terminos", "Términos"]]} />
      <HeroTitle
        label="Información comercial"
        title="Términos y condiciones."
        intro="Cada proyecto comienza con una propuesta que ambas partes pueden revisar."
      />
      <div className="paper">
        <div className="wrap section reading">
          <h2>Solicitud de cotización</h2>
          <p>
            Enviar una consulta inicia una conversación con el estudio. El
            alcance, los honorarios, los pagos y las fechas se definen en una
            propuesta específica antes de empezar el trabajo.
          </p>
          <h2>Revisiones y entregables</h2>
          <p>
            La propuesta indica las rondas de ajustes, los formatos finales y
            las condiciones de uso y entrega de archivos editables.
          </p>
          <h2>Material del sitio</h2>
          <p>
            Para reproducir piezas del portafolio o utilizar la identidad de
            Nord Studios, solicita autorización al estudio.
          </p>
        </div>
      </div>
    </>
  );
}
