import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight, ArrowRight, Plus } from "lucide-react";
import { faqs, services, steps } from "@/config/es";
import { site, whatsapp } from "@/config/site";
import { articles, type Project } from "@/lib/content";
import { Structured } from "@/lib/seo";
export function Button({
  href,
  children,
  secondary = false,
}: {
  href: string;
  children: React.ReactNode;
  secondary?: boolean;
}) {
  return (
    <Link className={secondary ? "text-link" : "button"} href={href}>
      {children}
      {secondary ? <ArrowRight size={17} /> : <ArrowUpRight size={18} />}
    </Link>
  );
}
export function Label({ children }: { children: React.ReactNode }) {
  return (
    <p className="kicker">
      <i />
      {children}
    </p>
  );
}
export function HeroTitle({
  label,
  title,
  intro,
}: {
  label: string;
  title: string;
  intro: string;
}) {
  return (
    <div className="wrap page-intro">
      <Label>{label}</Label>
      <h1>{title}</h1>
      <p className="lead">{intro}</p>
    </div>
  );
}
export function Crumbs({ items }: { items: [string, string][] }) {
  return (
    <>
      <nav className="wrap crumbs" aria-label="Ruta de navegación">
        <Link href="/">Inicio</Link>
        {items.map(([href, label], i) => (
          <span key={href}>
            {" "}
            /{" "}
            {i === items.length - 1 ? label : <Link href={href}>{label}</Link>}
          </span>
        ))}
      </nav>
      {site.origin && (
        <Structured
          data={{
            "@type": "BreadcrumbList",
            itemListElement: [["/", "Inicio"], ...items].map(
              ([href, name], i) => ({
                "@type": "ListItem",
                position: i + 1,
                name,
                item: site.origin + href,
              }),
            ),
          }}
        />
      )}
    </>
  );
}
export function ServiceRows() {
  return (
    <div className="service-list">
      {services.map((s, i) => (
        <Link href={"/servicios/" + s.slug} key={s.slug}>
          <span className="index">0{i + 1}</span>
          <div>
            <h3>{s.name}</h3>
            <p>{s.intro}</p>
          </div>
          <ArrowUpRight className="row-arrow" />
        </Link>
      ))}
    </div>
  );
}
export function Process() {
  return (
    <section className="wrap section split">
      <div>
        <Label>Metodología</Label>
        <h2>
          Del brief a la
          <br />
          entrega final.
        </h2>
      </div>
      <ol className="steps">
        {steps.map(([title, body], i) => (
          <li key={title}>
            <span className="index">0{i + 1}</span>
            <div>
              <h3>{title}</h3>
              <p>{body}</p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
export function FAQ({ items = faqs }: { items?: string[][] }) {
  return (
    <section className="wrap section split">
      <div>
        <Label>Preguntas frecuentes</Label>
        <h2>
          Antes de
          <br />
          empezar.
        </h2>
      </div>
      <div className="faq">
        {items.map(([q, a]) => (
          <details key={q}>
            <summary>
              {q}
              <Plus size={19} />
            </summary>
            <p>{a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
export function Close() {
  return (
    <section className="closing">
      <div className="wrap">
        <Label>Hablemos de tu marca</Label>
        <h2>
          Hagamos algo
          <br />
          diferente.
        </h2>
        <Button href="/contacto">Solicitar una cotización</Button>
        {whatsapp() && (
          <Button secondary href={whatsapp()}>
            WhatsApp
          </Button>
        )}
      </div>
    </section>
  );
}
export function ProjectCards({ items }: { items: Project[] }) {
  return (
    <div className="cards">
      {items.map((p) => (
        <Link href={"/proyectos/" + p.slug} key={p.slug}>
          <div className="cover">
            <Image
              src={p.cover.src}
              alt={p.cover.alt}
              width={p.cover.width}
              height={p.cover.height}
              sizes="(max-width:740px) 90vw, 46vw"
            />
          </div>
          <p className="meta">
            {services.find((s) => s.slug === p.category)?.short}{" "}
            {p.year && " / " + p.year}
          </p>
          <h3>{p.title} ↗</h3>
        </Link>
      ))}
    </div>
  );
}
export function Footer() {
  return (
    <footer className="wrap">
      <div className="footer-grid">
        <div>
          <Image
            className="footer-logo"
            src="/brand/logo-light.png"
            width={711}
            height={149}
            alt="Nord Studios"
          />
          <p>
            Estudio creativo independiente
            <br />
            Trujillo, Perú
          </p>
        </div>
        <nav aria-label="Estudio">
          <b>Estudio</b>
          {[
            ["Inicio", "/"],
            ["Proyectos", "/proyectos"],
            ["Nosotros", "/nosotros"],
            ["Contacto", "/contacto"],
            ...(articles().length ? [["Blog", "/blog"]] : []),
          ].map(([v, h]) => (
            <Link key={h} href={h}>
              {v}
            </Link>
          ))}
        </nav>
        <nav aria-label="Disciplinas">
          <b>Servicios</b>
          {services.map((s) => (
            <Link key={s.slug} href={"/servicios/" + s.slug}>
              {s.short}
            </Link>
          ))}
        </nav>
        {(site.email || whatsapp() || site.socials.length > 0) && (
          <nav aria-label="Canales de contacto">
            <b>Contacto</b>
            {site.email && <a href={"mailto:" + site.email}>{site.email}</a>}
            {whatsapp() && <a href={whatsapp()}>WhatsApp</a>}
            {site.socials.map(([n, l]) => (
              <a key={n} href={l}>
                {n}
              </a>
            ))}
          </nav>
        )}
      </div>
      <div className="footline">
        <span>© {new Date().getFullYear()} Nord Studios</span>
        <Link href="/privacidad">Privacidad</Link>
        <Link href="/terminos">Términos y condiciones</Link>
      </div>
    </footer>
  );
}
