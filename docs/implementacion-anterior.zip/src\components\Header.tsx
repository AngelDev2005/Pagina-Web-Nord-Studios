"use client";
import { useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { usePathname } from "next/navigation";
export const nav = [
  ["/", "Inicio"],
  ["/proyectos", "Proyectos"],
  ["/servicios", "Servicios"],
  ["/nosotros", "Nosotros"],
  ["/contacto", "Contacto"],
];
export default function Header() {
  const path = usePathname(),
    dropdown = useRef<HTMLDetailsElement>(null);
  const links = nav.map(([href, label]) => (
    <Link
      key={href}
      href={href}
      aria-current={
        (href === "/" ? path === "/" : path.startsWith(href))
          ? "page"
          : undefined
      }
      onClick={() => {
        if (dropdown.current) dropdown.current.open = false;
      }}
    >
      {label}
    </Link>
  ));
  return (
    <header className="header">
      <div className="wrap head-inner">
        <Link href="/" aria-label="Nord Studios, inicio">
          <Image
            className="logo"
            src="/brand/logo-light.png"
            alt="Nord Studios"
            width={711}
            height={149}
            loading="eager"
            sizes="(max-width:740px) 145px, 214px"
          />
        </Link>
        <nav className="desktop-nav" aria-label="Principal">
          {links}
        </nav>
        <Link className="head-cta" href="/contacto">
          <span className="cta-long">Iniciar un proyecto</span>
          <span className="cta-short">Cotizar</span>
          <ArrowUpRight size={16} />
        </Link>
        <details
          ref={dropdown}
          className="menu"
          onKeyDown={(e) => {
            if (e.key === "Escape" && dropdown.current) {
              dropdown.current.open = false;
              dropdown.current.querySelector("summary")?.focus();
            }
          }}
        >
          <summary aria-label="Menú de navegación">
            <Menu className="menu-icon" />
            <X className="menu-close" />
          </summary>
          <nav aria-label="Principal móvil">{links}</nav>
        </details>
      </div>
    </header>
  );
}
